"use client"

import { Palette, Code, FileImage, Layers, Wand2, Download } from "lucide-react"

const categories = [
  {
    icon: Palette,
    title: "Design Assets",
    description: "UI kits, icons, illustrations, and graphic elements for your projects",
    count: "25+ items"
  },
  {
    icon: Code,
    title: "Templates",
    description: "Ready-to-use website templates, landing pages, and components",
    count: "30+ items"
  },
  {
    icon: FileImage,
    title: "Graphics",
    description: "High-resolution images, backgrounds, and textures",
    count: "20+ items"
  },
  {
    icon: Layers,
    title: "Mockups",
    description: "Professional product mockups for presentations and portfolios",
    count: "15+ items"
  },
  {
    icon: Wand2,
    title: "Effects & Filters",
    description: "Photoshop actions, presets, and creative effects",
    count: "10+ items"
  },
  {
    icon: Download,
    title: "Digital Downloads",
    description: "Fonts, brushes, patterns, and other digital resources",
    count: "20+ items"
  }
]

export function Categories() {
  return (
    <section id="categories" className="py-24 lg:py-32 bg-secondary/30">
      <div className="container mx-auto px-4 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4 tracking-tight">
            Browse by Category
          </h2>
          <p className="text-muted-foreground text-lg">
            Find exactly what you need from our curated collection of digital products
          </p>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.map((category, index) => (
            <div
              key={index}
              className="group relative p-6 bg-card rounded-lg border border-border hover:border-primary/50 transition-all duration-300 cursor-pointer"
            >
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center shrink-0 group-hover:bg-primary/20 transition-colors">
                  <category.icon className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground mb-2 group-hover:text-primary transition-colors">
                    {category.title}
                  </h3>
                  <p className="text-sm text-muted-foreground mb-3 leading-relaxed">
                    {category.description}
                  </p>
                  <span className="text-xs text-primary font-medium">
                    {category.count}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
