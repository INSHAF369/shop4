"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Star, ArrowUpRight } from "lucide-react"

const products = [
  {
    id: 1,
    title: "Modern UI Kit Pro",
    price: "$49",
    rating: 5.0,
    reviews: 128,
    image: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
    tag: "Best Seller"
  },
  {
    id: 2,
    title: "Minimal Icon Pack",
    price: "$29",
    rating: 4.9,
    reviews: 89,
    image: "linear-gradient(135deg, #f093fb 0%, #f5576c 100%)",
    tag: "New"
  },
  {
    id: 3,
    title: "Landing Page Templates",
    price: "$79",
    rating: 5.0,
    reviews: 156,
    image: "linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)",
    tag: "Popular"
  },
  {
    id: 4,
    title: "3D Illustration Bundle",
    price: "$59",
    rating: 4.8,
    reviews: 67,
    image: "linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)",
    tag: null
  },
  {
    id: 5,
    title: "Social Media Kit",
    price: "$39",
    rating: 4.9,
    reviews: 94,
    image: "linear-gradient(135deg, #fa709a 0%, #fee140 100%)",
    tag: "Trending"
  },
  {
    id: 6,
    title: "Dashboard UI Components",
    price: "$89",
    rating: 5.0,
    reviews: 112,
    image: "linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)",
    tag: null
  }
]

export function Products() {
  return (
    <section id="products" className="py-24 lg:py-32">
      <div className="container mx-auto px-4 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-16">
          <div>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4 tracking-tight">
              Featured Products
            </h2>
            <p className="text-muted-foreground text-lg max-w-xl">
              Hand-picked selection of our best digital products and designs
            </p>
          </div>
          <Link href="https://ballwool.com/shops/PixelPlusShop" target="_blank">
            <Button variant="outline" className="border-border hover:bg-secondary">
              View All Products
              <ArrowUpRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {products.map((product) => (
            <Link
              key={product.id}
              href="https://ballwool.com/shops/PixelPlusShop"
              target="_blank"
              className="group"
            >
              <div className="bg-card rounded-lg border border-border overflow-hidden hover:border-primary/50 transition-all duration-300">
                {/* Product Image */}
                <div 
                  className="aspect-[4/3] relative"
                  style={{ background: product.image }}
                >
                  {product.tag && (
                    <span className="absolute top-4 left-4 px-3 py-1 bg-primary text-primary-foreground text-xs font-medium rounded-full">
                      {product.tag}
                    </span>
                  )}
                  <div className="absolute inset-0 bg-foreground/0 group-hover:bg-foreground/5 transition-colors" />
                </div>

                {/* Product Info */}
                <div className="p-5">
                  <h3 className="font-semibold text-foreground mb-2 group-hover:text-primary transition-colors">
                    {product.title}
                  </h3>
                  <div className="flex items-center justify-between">
                    <span className="text-xl font-bold text-primary">
                      {product.price}
                    </span>
                    <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                      <Star className="w-4 h-4 fill-primary text-primary" />
                      <span>{product.rating}</span>
                      <span>({product.reviews})</span>
                    </div>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
