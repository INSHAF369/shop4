"use client"

import { CheckCircle2, Zap, Shield, Clock } from "lucide-react"

const features = [
  {
    icon: Zap,
    title: "Instant Downloads",
    description: "Get immediate access to all purchased products with secure download links"
  },
  {
    icon: Shield,
    title: "Quality Guaranteed",
    description: "Every product is carefully reviewed to ensure the highest quality standards"
  },
  {
    icon: Clock,
    title: "Regular Updates",
    description: "Products are continuously updated with new features and improvements"
  }
]

const benefits = [
  "Premium quality digital assets",
  "Compatible with popular design tools",
  "Commercial license included",
  "Dedicated customer support",
  "Free updates for life",
  "100% satisfaction guarantee"
]

export function About() {
  return (
    <section id="about" className="py-24 lg:py-32 bg-secondary/30">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Column */}
          <div>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-6 tracking-tight text-balance">
              Why Choose PixelPlusShop?
            </h2>
            <p className="text-muted-foreground text-lg mb-8 leading-relaxed">
              {"We're passionate about creating digital products that help designers, developers, and creators bring their visions to life. Our commitment to quality and customer satisfaction sets us apart."}
            </p>

            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {benefits.map((benefit, index) => (
                <li key={index} className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-primary shrink-0" />
                  <span className="text-foreground text-sm">{benefit}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            {features.map((feature, index) => (
              <div
                key={index}
                className="p-6 bg-card rounded-lg border border-border"
              >
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                    <feature.icon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground mb-2">
                      {feature.title}
                    </h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {feature.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
